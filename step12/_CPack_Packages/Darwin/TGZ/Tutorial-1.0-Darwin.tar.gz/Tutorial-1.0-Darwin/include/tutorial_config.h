// This file is used as input for CMake to create the tutorial_config.h file for us,
// swapping out 1 and 0 for the associated CMake variables
// created when we specified project(Tutorial VERSION 1.0) in CMakeLists.txt
#define Tutorial_VERSION_MAJOR 1
#define Tutorial_VERSION_MINOR 0
